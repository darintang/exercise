package com.dt.curve;

import java.time.LocalTime;

public class MinQtyAtTimeFn implements IQtyAtTimeFn {

	// This will be a simple Fn. It will be based off the input Fn, where we
	// will always be 5% off the input, until 90% of the ideal where we converge
	// with input Fn. We can have a more indepth discussion of how the curve
	// look like to yield a better performance

	private static final double OFFSET_FROM_BASE = 0.95;
	private static final double MERGE_TO_IDEAL_PCT = 0.95;

	private final IQtyAtTimeFn base;
	private final double idealQtyOverride;

	public MinQtyAtTimeFn(IQtyAtTimeFn base, long orderQty) {
		this.base = base;
		idealQtyOverride = orderQty * MERGE_TO_IDEAL_PCT;
	}

	@Override
	public double valueFor(LocalTime time) {
		double baseQty = base.valueFor(time);
		return (baseQty >= idealQtyOverride) ? baseQty : baseQty * OFFSET_FROM_BASE;
	}
}