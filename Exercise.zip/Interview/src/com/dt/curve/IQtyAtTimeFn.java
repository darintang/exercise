package com.dt.curve;

import java.time.LocalTime;

public interface IQtyAtTimeFn {
	public double valueFor(LocalTime time);
}
