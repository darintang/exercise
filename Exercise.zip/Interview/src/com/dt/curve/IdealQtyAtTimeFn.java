package com.dt.curve;

import java.time.LocalTime;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.dt.core.Stats;

public class IdealQtyAtTimeFn implements IQtyAtTimeFn {
	// The handling of volume profile itself can be a whole project on its own.
	// For the demo on how to trade a VWAP, we'll assume that the order will
	// always be of the same duration with simple storage of the data points
	// that doesn't allow skewing and redrawing of what's already plotted out

	private static final int LENGTH_OF_ORDER_IN_MINS = 100;
	private static final double SECONDS_IN_MINUTE = 60D;

	private TreeMap<LocalTime, DataPoint> dataPoints;

	private class DataPoint {
		double cum, delta;

		public DataPoint(double cum, double delta) {
			this.cum = cum;
			this.delta = delta;
		}

		public double getCumQty() {
			return cum;
		}

		public double getDelta() {
			return delta;
		}
	}

	public IdealQtyAtTimeFn(long orderQty, Stats stats, LocalTime start) {
		dataPoints = new TreeMap<LocalTime, DataPoint>();

		double[] cumPct = stats.getCumPctVol();
		double prevCum = 0;

		dataPoints.put(start, new DataPoint(0, 0));
		for (int i = 0; i < LENGTH_OF_ORDER_IN_MINS; i++) {
			double cumQty = cumPct[i] * orderQty;
			double delta = cumQty - prevCum;
			prevCum = cumQty;

			dataPoints.put(start.plusMinutes(i+1), new DataPoint(cumQty, delta));
		}
	}

	@Override
	public double valueFor(LocalTime time) {
		// Minute Interval
		if (dataPoints.containsKey(time))
			return dataPoints.get(time).getCumQty();

		// Within the bucket
		double ratio = (time.toSecondOfDay() - dataPoints.lowerKey(time).toSecondOfDay()) / SECONDS_IN_MINUTE;
		double lowCum = dataPoints.lowerEntry(time).getValue().getCumQty();

		Entry<LocalTime, DataPoint> entry = dataPoints.ceilingEntry(time);
		if (entry == null) {
			return dataPoints.lastEntry().getValue().getCumQty();
		}

		return lowCum + ratio * entry.getValue().getDelta();
	}
}
