package com.dt.curve;

import java.time.LocalTime;

import com.dt.core.Stats;

public class MaxQtyAtTimeFn implements IQtyAtTimeFn {

	// This will be a simple Fn. It will be based off the input Fn, where we
	// will consider the queue time of the name and look forward how much qty we
	// need to prequeue. We can have a more indepth discussion about what else
	// can be built into this function to yield better performances

	private final IQtyAtTimeFn base;
	private final long queueTime;

	public MaxQtyAtTimeFn(IQtyAtTimeFn base, Stats stats) {
		this.base = base;
		queueTime = stats.getAvgQueueTimeSecs();
	}

	@Override
	public double valueFor(LocalTime time) {
		return base.valueFor(time.plusSeconds(queueTime));
	}
}