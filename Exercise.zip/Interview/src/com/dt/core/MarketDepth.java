package com.dt.core;

import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class MarketDepth implements IDepth {

	private final TreeMap<IPrice, Long> askMap;
	private final TreeMap<IPrice, Long> bidMap;

	public MarketDepth(TreeMap<IPrice, Long> bidMap, TreeMap<IPrice, Long> askMap) {
		this.bidMap = bidMap;
		this.askMap = askMap;
	}

	@Override
	public IPrice getBestAsk() {
		return getBestPrice(false);
	}

	@Override
	public IPrice getBestBid() {
		return getBestPrice(true);
	}

	@Override
	public IPrice getBestPrice(boolean isBuy) {
		TreeMap<IPrice, Long> map = isBuy ? bidMap : askMap;
		Entry<IPrice, Long> entry = map.firstEntry();
		return (entry != null) ? entry.getKey() : null;
	}

	@Override
	public long getBestAskSize() {
		return getBestSize(false);
	}

	@Override
	public long getBestBidSize() {
		return getBestSize(true);
	}

	@Override
	public long getBestSize(boolean isBuy) {
		TreeMap<IPrice, Long> map = isBuy ? bidMap : askMap;
		Entry<IPrice, Long> entry = map.firstEntry();
		return (entry != null) ? entry.getValue() : 0;
	}

	@Override
	public String shortString() {
		StringBuilder build = new StringBuilder();
		IPrice bid = getBestPrice(true);
		if (bid != null) {
			build.append(bid.getDoubleValue()).append(":").append(getBestSize(true));
		} else {
			build.append("null");
		}
		build.append(" / ");
		IPrice ask = getBestPrice(false);
		if (bid != null) {
			build.append(ask.getDoubleValue()).append(":").append(getBestSize(false));
		} else {
			build.append("null");
		}
		return build.toString();
	}

	@Override
	public Map<IPrice, Long> getAsks() {
		return askMap;
	}

	@Override
	public Map<IPrice, Long> getBids() {
		return bidMap;
	}
}
