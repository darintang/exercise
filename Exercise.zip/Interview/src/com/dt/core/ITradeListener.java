package com.dt.core;

public interface ITradeListener {
	public void onTrade(Trade trade);
}
