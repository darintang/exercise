package com.dt.core;

import java.time.LocalTime;

public class DayTiming {

	// Assume that this is a 100minutes trading day with no auctions for
	// simplicity
	
	public static final LocalTime DAY_END_TIME = LocalTime.parse("10:40");
	public static final LocalTime DAY_START_TIME = LocalTime.parse("09:00");
	
	public static final int MINUTE_IN_SECONDS = 60;
}
