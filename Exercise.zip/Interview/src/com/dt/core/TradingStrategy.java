package com.dt.core;

public enum TradingStrategy {
	VWAP,POV;
}
