package com.dt.core;

import java.util.Comparator;

public class TradingMath {

	private final long lotSize;
	private final Comparator<IPrice> comp;
	
	public TradingMath(boolean isBuy, Instrument inst) {
		lotSize = inst.getLotSize();
		comp = isBuy ? BUY_COMP : SELL_COMP;
	}
	
	public long roundDownLots(double qty){
		return (Math.round(qty / lotSize) * lotSize);
	}
	
	public boolean priceIsPassive(IPrice what, IPrice ref) {
		return comp.compare(what, ref) > 0;
	}
	
	public boolean priceIsPassiveOrEquals(IPrice what, IPrice ref) {
		return comp.compare(what, ref) >= 0;
	}
	
	public boolean priceIsAggressive(IPrice what, IPrice ref) {
		return comp.compare(what, ref) < 0;
	}
	
	public boolean priceIsAggressiveOrEquals(IPrice what, IPrice ref) {
		return comp.compare(what, ref) <= 0;
	}
	
	public static Comparator<IPrice> BUY_COMP = new Comparator<IPrice>(){
		@SuppressWarnings("unused")
		@Override
		public int compare(IPrice o1, IPrice o2) {
			if (o1 == o2) return 0;
			if (o1.isMarket()) return -1;
			if (o2.isMarket()) return 1;
			if (o1 == null) return 1;
			if (o2 == null) return -1;
			double o1dbl = o1.getDoubleValue();
			double o2dbl = o2.getDoubleValue();
			if (o1dbl == o2dbl) return 0;
			if (o1dbl == 0) return 1;
			if (o2dbl == 0) return -1;
			return Double.compare(o2dbl, o1dbl);
		}
		
	};

	public static Comparator<IPrice> SELL_COMP = new Comparator<IPrice>(){
		@SuppressWarnings("unused")
		@Override
		public int compare(IPrice o1, IPrice o2) {
			if (o1 == o2) return 0;
			if (o1.isMarket()) return -1;
			if (o2.isMarket()) return 1;
			if (o1 == null) return 1;
			if (o2 == null) return -1;
			double o1dbl = o1.getDoubleValue();
			double o2dbl = o2.getDoubleValue();
			if (o1dbl == o2dbl) return 0;
			if (o1dbl == 0) return 1;
			if (o2dbl == 0) return -1;
			return Double.compare(o1dbl, o2dbl);
		}
		
	};
}
