package com.dt.core;

public class Instrument {
	// This should ideally be created for each name we're trading. For the
	// purpose of this exercise, the instrument will be fixed as we support only 1 name
	
	public long getLotSize() {
		return 1;
	}
	
	public double getTickSize() {
		return 0.5;
	}

}
