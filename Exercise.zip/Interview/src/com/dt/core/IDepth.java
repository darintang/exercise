package com.dt.core;

import java.util.Map;

public interface IDepth {
	public IPrice getBestAsk();
	public IPrice getBestBid();
	public IPrice getBestPrice(boolean isBuy);
	
	public long getBestAskSize();
	public long getBestBidSize();
	public long getBestSize(boolean isBuy);
	
	public Map<IPrice, Long> getAsks();
	public Map<IPrice, Long> getBids();
	
	public String shortString();
}
