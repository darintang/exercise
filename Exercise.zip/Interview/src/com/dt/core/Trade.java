package com.dt.core;

import java.time.LocalTime;

public class Trade {
	private IPrice px;
	private long size;
	private LocalTime time;
	
	public Trade(IPrice px, long size, LocalTime time) {
		this.px = px;
		this.size = size;
		this.time  = time;
	}
	
	public IPrice getPrice() {
		return px;
	}
	
	public long getSize() {
		return size;
	}
	
	public LocalTime getTime() {
		return time;
	}
	
	public String shortString() {
		StringBuilder build = new StringBuilder();
		build.append(px.getDoubleValue()).append(":").append(size).append(" @ ").append(time);
		return build.toString();
	}
}
