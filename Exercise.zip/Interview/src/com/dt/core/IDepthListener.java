package com.dt.core;

public interface IDepthListener {
	public void onDepth(IDepth depth);
}
