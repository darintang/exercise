package com.dt.core;

public class Price implements IPrice {

	public static Price MARKET = new Price(0.0) {
		@Override
		public boolean isMarket() {
			return true;
		}
	};
	
	private final double value;
	
	public Price(double price) {
		value = price;
	}
	
	@Override
	public double getDoubleValue() {
		return value;
	}
	
	public boolean isMarketOrder() {
		return value == 0d;
	}

	@Override
	public boolean isMarket() {
		return false;
	}
}
