package com.dt.core;

public interface IEventListener {
	public void onEvent(Event e);
}
