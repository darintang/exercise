package com.dt.core;

public interface IPrice {
	public double getDoubleValue();
	public boolean isMarket();
}
