package com.dt.core.orders;

import java.util.UUID;

import com.dt.core.IPrice;

public abstract class AbstractOrder implements IOrder{
	
	private String id;
	private IPrice price;
	private long size;
	
	public AbstractOrder(IPrice price, long size) {
		this.price = price;
		this.size = size;
		//This is really awful but not the main focus of this exercise anyway
		id = UUID.randomUUID().toString();
	}
	
	public IPrice getPrice() {
		return price;
	}
	
	public String getID() {
		return id;
	}
	
	public long getSize() {
		return size;
	}
}
