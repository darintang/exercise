package com.dt.core.orders;

import java.util.Map;
import java.util.TreeMap;

import com.dt.core.IPrice;
import com.dt.core.TradingMath;

public class StrategyPartition {

	private BasicPartition aggressive, passive;
	private final long maxQty;
	private final boolean isBuy;

	public StrategyPartition(boolean isBuy, long maxQty) {
		aggressive = new BasicPartition(isBuy, PartitionType.AGGRESSIVE, maxQty);
		passive = new BasicPartition(isBuy, PartitionType.PASSIVE, maxQty);
		this.maxQty = maxQty;
		this.isBuy = isBuy;
	}

	public IPartition getPartition(PartitionType type) {
		switch (type) {
		case AGGRESSIVE:
			return aggressive;
		case PASSIVE:
		default:
			return passive;
		}
	}

	// Call this after using aggressive partition so that we reallocate the max
	// to passive accordingly based on what we've already used
	public void confirmAggressiveAllocation() {
		long aggressiveQty = aggressive.getTotalQty();
		aggressive.setMax(aggressiveQty);
		passive.setMax(maxQty - aggressiveQty);
	}

	// Different partitions may contain the same price (i.e. catchup might do
	// passive) safer to just merge the goal into 1
	public Map<IPrice, Long> mergePartitions() {
		Map<IPrice, Long> goal = new TreeMap<IPrice, Long>(isBuy ? TradingMath.BUY_COMP : TradingMath.SELL_COMP);

		mergePartition(aggressive.getGoal(), goal);
		mergePartition(passive.getGoal(), goal);

		return goal;
	}

	// Drop any goal with 0 qty allocated
	private void mergePartition(Map<IPrice, Long> from, Map<IPrice, Long> to) {
		for (IPrice price : from.keySet()) {
			long current = from.get(price);
			Long existing = to.get(price);

			if (existing != null) {
				to.put(price, current + existing.longValue());
			} else if (current > 0) {
				to.put(price, current);
			}
		}
	}

	@Override
	public String toString() {
		StringBuilder build = new StringBuilder();
		build.append("[");
		build.append(aggressive.toString()).append(" ").append(passive.toString()).append(" ]");
		return build.toString();
	}
}
