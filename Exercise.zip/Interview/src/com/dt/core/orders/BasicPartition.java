package com.dt.core.orders;

import java.util.Map;
import java.util.TreeMap;

import com.dt.core.IPrice;
import com.dt.core.TradingMath;

public class BasicPartition implements IPartition {

	private long maxQty;
	private Map<IPrice, Long> goal;
	private PartitionType type;
	
	public BasicPartition(boolean isBuy, PartitionType type, long maxQty) {
		goal = new TreeMap<IPrice, Long>(isBuy ? TradingMath.BUY_COMP : TradingMath.SELL_COMP);
		this.maxQty = maxQty;
		this.type = type;
	}
	
	public void setMax(long max) {
		maxQty = max;
		// Always roundQty after adjusting max
		roundQty();
	}
	
	@Override
	public void incr(IPrice price, long qty) {
		Long existing = goal.get(price);
		
		if (existing == null) {
			existing = 0L;
		}
		
		goal.put(price, qty + existing.longValue());
	}

	@Override
	public long getTotalQty() {
		long usedQty = 0;
		for (IPrice price : goal.keySet()) {
			usedQty += goal.get(price);
		}
		return usedQty;
	}

	@Override
	public void roundQty() {
		long usedQty = 0;
		for (IPrice price : goal.keySet()) {
			long orderQty = goal.get(price);
			if (usedQty == maxQty) {
				orderQty = 0;
			} else if (orderQty + usedQty > maxQty) {
				orderQty = maxQty - usedQty;
			}
			
			goal.put(price, orderQty);
			usedQty += orderQty;
		}
	}

	@Override
	public PartitionType getType() {
		return type;
	}

	@Override
	public boolean isEmpty() {
		return goal.isEmpty();
	}

	@Override
	public String toString() {
		StringBuilder build = new StringBuilder();
		for (IPrice price : goal.keySet()) {
			build.append(price.getDoubleValue()).append(":").append(goal.get(price)).append(" ");
		}

		return build.toString();
	}

	@Override
	public boolean isSendable() {
		return maxQty > 0;
	}

	@Override
	public Map<IPrice, Long> getGoal() {
		return goal;
	}
}