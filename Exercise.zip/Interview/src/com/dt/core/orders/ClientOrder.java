package com.dt.core.orders;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.dt.core.DayTiming;
import com.dt.core.IPrice;
import com.dt.core.Instrument;
import com.dt.core.Stats;
import com.dt.core.TradingMath;
import com.dt.core.TradingStrategy;
import com.dt.tracking.CompositeTargetRatioFn;
import com.dt.tracking.TargetRatioFn;

public class ClientOrder extends AbstractOrder {

	private final TradingMath tmath;
	private final Stats stats;
	private final TradingStrategy strategy;
	private final boolean isBuy;
	private final Instrument inst;

	private List<IOrder> activeChildOrders;
	private long cumQty;
	private LocalTime startTime, endTime;
	private CompositeTargetRatioFn targetFns;

	public ClientOrder(boolean isBuy, Instrument inst, IPrice price, long size, TradingStrategy strategy) {
		super(price, size);
		stats = new Stats();
		this.strategy = strategy;
		this.isBuy = isBuy;
		this.inst = inst;
		activeChildOrders = new ArrayList<IOrder>();
		tmath = new TradingMath(isBuy, inst);
		targetFns = new CompositeTargetRatioFn(isBuy, tmath);
		// Assumption is order duration is fixed for the example
		startTime = DayTiming.DAY_START_TIME;
		endTime = DayTiming.DAY_END_TIME;
	}

	public Stats getStats() {
		return stats;
	}

	public LocalTime getStartTime() {
		return startTime;
	}

	public LocalTime getEndTime() {
		return endTime;
	}

	public TradingStrategy getTradingStrategy() {
		return strategy;
	}

	public TradingMath getTradingMath() {
		return tmath;
	}

	public String logOrder() {
		StringBuilder builder = new StringBuilder();
		builder.append(getID()).append(" Side:").append(isBuy ? "Buy" : "Sell").append(" Strategy:")
				.append(getTradingStrategy()).append(" Price:").append(getPrice().getDoubleValue()).append(" Size:")
				.append(getSize());
		return builder.toString();
	}

	public long getCumQty() {
		return cumQty;
	}

	public List<IOrder> getActiveChildOrders() {
		return activeChildOrders;
	}

	public void applyFill(IOrder order) {
		cumQty += order.getSize();
	}

	public Instrument getInstrument() {
		return inst;
	}

	public boolean isBuy() {
		return isBuy;
	}

	public CompositeTargetRatioFn getCompositeTargetRatioFn() {
		return targetFns;
	}

	public void addTargetRatioFn(IPrice px, TargetRatioFn target) {
		targetFns.addTarget(px, target);
	}

}
