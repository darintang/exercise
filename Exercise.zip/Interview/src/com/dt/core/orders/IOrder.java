package com.dt.core.orders;

import com.dt.core.IPrice;

public interface IOrder {

	public IPrice getPrice();
	
	public String getID();
	
	public long getSize();
}
