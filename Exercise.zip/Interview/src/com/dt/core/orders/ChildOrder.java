package com.dt.core.orders;

import com.dt.core.IPrice;

public class ChildOrder extends AbstractOrder {
	public ChildOrder(IPrice price, long size) {
		super(price, size);
	}
}
