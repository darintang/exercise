package com.dt.core.orders;

import java.util.List;
import java.util.Map;

import com.dt.core.IPrice;

/**
 * The purpose of this class is to achieve the input goal by reusing as much as
 * we can on the list of existing orders. This can also a project by itself
 * given the complexity of amends and a large number of scenarios to cater to.
 * Additionally there can also be logic within here to prevent new slices from
 * being made if the change in goal is small. In the example, we shall assume
 * that we will always cancel and create new orders (i.e. the existing goal will
 * not be reused )
 *
 */
public class OrdersAllocator {
	public void allocate(List<IOrder> existing, Map<IPrice, Long> goal) {
		existing.clear();
		for (IPrice price : goal.keySet()) {
			existing.add(new ChildOrder(price, goal.get(price)));
		}
	}
}
