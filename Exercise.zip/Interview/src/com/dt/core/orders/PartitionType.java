package com.dt.core.orders;

public enum PartitionType {
	AGGRESSIVE, PASSIVE;
}
