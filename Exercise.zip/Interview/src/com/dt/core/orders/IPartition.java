package com.dt.core.orders;

import java.util.Map;

import com.dt.core.IPrice;

public interface IPartition {

	public void incr(IPrice price, long qty);
	
	public long getTotalQty();
	
	public void roundQty();
	
	public boolean isEmpty();
	
	public boolean isSendable();
	
	public PartitionType getType();
	
	public Map<IPrice, Long> getGoal();
}
