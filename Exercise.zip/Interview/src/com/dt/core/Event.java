package com.dt.core;

public class Event {

	public static enum Type {
		TIMER,FILL;
	}
	
	@SuppressWarnings("unused")
	private Type type;
	
	public Event(Type type) {
		this.type = type;
	}
}
