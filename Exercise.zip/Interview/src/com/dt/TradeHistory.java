package com.dt;

import java.util.ArrayList;
import java.util.List;

import com.dt.core.ITradeListener;
import com.dt.core.Trade;

public class TradeHistory implements ITradeListener {

	private static TradeHistory instance = null;

	private List<Trade> list;

	protected TradeHistory() {
		list = new ArrayList<Trade>();
	}

	public static TradeHistory getInstance() {
		if (instance == null) {
			instance = new TradeHistory();
		}
		return instance;
	}

	@Override
	public void onTrade(Trade trade) {
		list.add(trade);
	}

	public void updateListener(ITradeListener listener, Trade lastVisible) {
		for (int index = Math.max(0, list.indexOf(lastVisible)+1); index < list.size(); index++) {
			listener.onTrade(list.get(index));
		}
	}
}
