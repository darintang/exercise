package com.dt;

import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;

public class ClockManager {

	// Basically allows us to control the clock and how it progress in our
	// simulation

	private static ClockManager instance = null;

	// Should be implemented as a service but using this as a way to show that
	// the Algo can also handle timer events
	private static Map<LocalTime, Boolean> scheduler;

	private static LocalTime now;

	protected ClockManager() {
		scheduler = new HashMap<LocalTime, Boolean>();
	}

	public static ClockManager getInstance() {
		if (instance == null) {
			instance = new ClockManager();
		}
		return instance;
	}

	public static void setNow(LocalTime newTime) {
		now = newTime;
	}

	public static LocalTime getTime() {
		return now;
	}

	public static void addEvent(LocalTime time) {
		scheduler.put(time, true);
	}

	public static boolean hasEventNow() {
		return scheduler.get(now) != null;
	}
}
