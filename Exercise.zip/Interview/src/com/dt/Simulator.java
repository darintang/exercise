package com.dt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import com.dt.core.Event;
import com.dt.core.IDepth;
import com.dt.core.IDepthListener;
import com.dt.core.IEventListener;
import com.dt.core.IPrice;
import com.dt.core.ITradeListener;
import com.dt.core.Instrument;
import com.dt.core.MarketDepth;
import com.dt.core.Price;
import com.dt.core.Trade;
import com.dt.core.TradingMath;
import com.dt.core.TradingStrategy;
import com.dt.core.orders.ClientOrder;
import com.dt.core.orders.IOrder;
import com.dt.tracking.TargetRatioFn;

import org.apache.logging.log4j.*;

@SuppressWarnings("unused")
public class Simulator {

	private static Logger logger = LogManager.getLogger();

	private List<ITradeListener> tradeDispatcher;
	private List<IDepthListener> depthDispatcher;
	private List<IEventListener> eventDispatcher;

	// Need the following to simulate fills
	private ClientOrder order;
	private TradingMath tmath;

	public Simulator() {
		tradeDispatcher = new ArrayList<ITradeListener>(5);
		depthDispatcher = new ArrayList<IDepthListener>(5);
		eventDispatcher = new ArrayList<IEventListener>(5);

		tradeDispatcher.add(TradeHistory.getInstance());
		depthDispatcher.add(CurrentDepth.getInstance());

		ClockManager.getInstance();
	}

	public void addOrder(ClientOrder order) {
		this.order = order;
		tmath = new TradingMath(order.isBuy(), order.getInstrument());
		EvalStrategy container = new EvalStrategy();
		try {
			container.onInit(order);
			tradeDispatcher.add(container);
			depthDispatcher.add(container);
			eventDispatcher.add(container);
		} catch (Exception e) {
			logger.error("Could not trade order." + e.getMessage());
			e.printStackTrace();
		}
	}

	private void receiveTrade(Trade trade) {
		for (ITradeListener listener : tradeDispatcher) {
			listener.onTrade(trade);
		}
	}

	private void receiveDepth(IDepth depth) {
		for (IDepthListener listener : depthDispatcher) {
			listener.onDepth(depth);
		}
	}

	private void receiveEvent(Event event) {
		for (IEventListener listener : eventDispatcher) {
			listener.onEvent(event);
		}
	}

	private void generateFill(IPrice price) {
		if (!order.getActiveChildOrders().isEmpty()) {
			Iterator<IOrder> iter = order.getActiveChildOrders().iterator();
			while (iter.hasNext()) {
				IOrder child = iter.next();
				if (tmath.priceIsAggressiveOrEquals(child.getPrice(), price)) {
					order.applyFill(child);
					iter.remove();
				}
			}
		}
	}

	private IDepth createDepth(String string) {
		TreeMap<IPrice, Long> bidMap = new TreeMap<IPrice, Long>(TradingMath.BUY_COMP);
		TreeMap<IPrice, Long> askMap = new TreeMap<IPrice, Long>(TradingMath.SELL_COMP);
		TreeMap<IPrice, Long> current = null;
		String[] values = string.split(",");

		for (String value : values) {
			if (value.startsWith("B")) {
				current = bidMap;
				continue;
			} else if (value.startsWith("A")) {
				current = askMap;
				continue;
			}

			if (current == null)
				continue;

			String[] entry = value.split(":");
			if (entry.length == 2) {
				current.put(new Price(Double.parseDouble(entry[0])), Long.parseLong(entry[1]));
			}
		}

		return new MarketDepth(bidMap, askMap);
	}

	private void moveClock(String line) {
		String time = line.substring(0, 8);
		LocalTime now = ClockManager.getTime();
		LocalTime next = LocalTime.parse(time);

		if (now != null) {
			for (int i = 1; !now.plusSeconds(i).isAfter(next); i++) {
				ClockManager.setNow(now.plusSeconds(i));
				if (ClockManager.hasEventNow()) {
					receiveEvent(new Event(Event.Type.TIMER));
				}
			}
		} else {
			ClockManager.setNow(next);
		}
	}

	private Trade createTrade(String line) {
		String[] values = line.split(",");
		LocalTime time = LocalTime.parse(values[0]);
		String[] trade = values[2].split(":");
		return new Trade(new Price(Double.parseDouble(trade[0])), Long.parseLong(trade[1]), time);
	}

	public void processLine(String line) {
		moveClock(line);
		if (line.contains("B") || line.contains("A")) {
			IDepth depth = createDepth(line);
			if (order != null)
				generateFill(depth.getBestPrice(!order.isBuy()));
			receiveDepth(depth);
		} else if (line.contains("T")) {
			Trade trade = createTrade(line);
			receiveTrade(trade);
		}
	}

	public static void main(String[] args) {

		// Ideally we should validate the order if all params are present and if
		// it's a "Safe" order to trade in Algo prior to putting it into Algo.

		// VWAP Order
		ClientOrder order = new ClientOrder(true, new Instrument(), new Price(102d), 10000, TradingStrategy.VWAP);

		// Comment out the next 2 lines if we dont need a client max
//		 TargetRatioFn max = new TargetRatioFn(0, 0, 0.05);
//		 order.addTargetRatioFn(Price.MARKET, max);

		// Speedup instructions. Ideal = Max for Speedup. Current speedup with
		// VWAP impl only does additional passive posting.
//		 TargetRatioFn speedup = new TargetRatioFn(0.2, 0.2, 0.2);
//		 order.addTargetRatioFn(new Price(101), speedup);

		// POV Order
		// ClientOrder order = new ClientOrder(true, new Instrument(), Price.MARKET, 10000, TradingStrategy.POV);
		// TargetRatioFn target = new TargetRatioFn(0, 0.05, 0);
		// order.addTargetRatioFn(Price.MARKET, target);
		// TargetRatioFn speedup = new TargetRatioFn(0, 0.2, 0.2);
		// order.addTargetRatioFn(new Price(100.5), speedup);

		Simulator sim = new Simulator();

		String csvFile = "C:\\Work\\Interview\\marketData.csv";
		BufferedReader br = null;
		String line = "";

		int lineCount = 0;
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				// Should only send the order once we have a market data image
				if (lineCount == 1)
					sim.addOrder(order);
				sim.processLine(line);
				lineCount++;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
