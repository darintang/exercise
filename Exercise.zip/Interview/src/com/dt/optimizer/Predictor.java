package com.dt.optimizer;

import java.time.LocalTime;

import com.dt.core.DayTiming;
import com.dt.core.Stats;

public class Predictor {

	private Stats stats;
	double[] cumPct;

	public Predictor(Stats stats) {
		this.stats = stats;
		cumPct = stats.getCumPctVol();
	}

	/**
	 * The purpose of this method is to predict how much quantity we will see on
	 * the market between the period specified. The logic below is purely based
	 * on historical. We can however improve this to look at the real time
	 * volume and take a weighted average between the two. This can help to
	 * address some of the unexpected volatility that we may see on the market. 
	 * 
	 * @param start
	 * @param end
	 * @return
	 */
	public double getPredictedQty(LocalTime start, LocalTime end) {
		int startBucket = getBucket(start);
		int endBucket = getBucket(end);

		double delta = cumPct[endBucket] - cumPct[startBucket];

		return delta * stats.getMedianVolume();
	}

	private int getBucket(LocalTime time) {
		int ref = time.toSecondOfDay();
		int startOfDay = DayTiming.DAY_START_TIME.toSecondOfDay();

		return Math.min(cumPct.length -1, Math.max(0, ref - startOfDay)/DayTiming.MINUTE_IN_SECONDS );
	}

}
