package com.dt.optimizer;

import com.dt.core.orders.IPartition;

public interface ICatchupOptimizer extends IDepthDependentPlugins {
	public boolean shouldCatchup();
	public void doCatchUp(IPartition part, long qty);

}
