package com.dt.optimizer;

import java.time.LocalTime;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.dt.TradeHistory;
import com.dt.core.IDepth;
import com.dt.core.IPrice;
import com.dt.core.Stats;
import com.dt.core.Trade;
import com.dt.core.TradingMath;
import com.dt.core.orders.ClientOrder;
import com.dt.core.orders.StrategyPartition;
import com.dt.optimizer.plugins.EvalSchemePlugin;
import com.dt.optimizer.plugins.PriceLimitsPlugin;
import com.dt.optimizer.utils.FPUtils;
import com.dt.optimizer.utils.LoggingUtils;
import com.dt.tracking.MarketVolumeTracker;
import com.dt.tracking.TradeFilter;

public abstract class BasicQtyOptimizer implements IOptimizer {

	private static Logger logger = LogManager.getLogger(BasicQtyOptimizer.class);

	private EvalSchemePlugin evalScheme;
	private PriceLimitsPlugin pxLimit;

	protected Stats stats;
	protected TradingMath tmath;
	protected boolean isBuy;
	protected IDepth depth;
	protected LocalTime now;
	protected TradeFilter tradeFilter;
	
	private final long orderQty;
	private final IPrice limit;
	private final Predictor pred;
	private final MarketVolumeTracker mktStats;
	protected final ClientOrder order;

	public BasicQtyOptimizer(ClientOrder order) {
		evalScheme = new EvalSchemePlugin();
		isBuy = order.isBuy();
		tmath = order.getTradingMath();
		pxLimit = new PriceLimitsPlugin(order, tmath);

		this.order = order;
		orderQty = order.getSize();
		stats = order.getStats();
		pred = new Predictor(stats);
		limit = order.getPrice();
		tradeFilter = new TradeFilter(limit, tmath);
		mktStats = new MarketVolumeTracker(tradeFilter);
	}

	protected boolean beyondLimit(IPrice px) {
		if (limit.isMarket())
			return false;

		return tmath.priceIsAggressive(px, limit);
	}

	protected Predictor getPredictor() {
		return pred;
	}

	public abstract void updateCachedValues();

	protected long getOrderQty() {
		return orderQty;
	}

	protected long getCumQty() {
		return order.getCumQty();
	}

	public boolean wantToOptimize(IDepth depth) {
		return evalScheme.wantToOptimize(depth);
	}

	public boolean wantToOptimize(Trade trade) {
		return evalScheme.wantToOptimize(trade);
	}

	protected void updateTradeListeners() {
		TradeHistory.getInstance().updateListener(mktStats, mktStats.getLastTrade());
	}
	
	@Override
	public Map<IPrice, Long> optimize(IEvalContext ctx) {
		now = ctx.getTime();
		depth = ctx.getDepth();
		
		updateTradeListeners();
		logHeader();
		updateCachedValues();
		StrategyPartition partitions = computeGoal();
		Map<IPrice, Long> output = partitions.mergePartitions();
		logger.info("Strategy Out: " + LoggingUtils.logStrategyGoal(output));
		if (pxLimit.adjustPrice(output)) {
			logger.info("RePrice: " + LoggingUtils.logStrategyGoal(output));
		}

		// ideally try to check if the qty at this stage is too large, if it is
		// we should reduce it to avoid signaling risks

		return output;
	}

	private void logHeader() {
		long cumQty = getCumQty();
		long mktQty = mktStats.getMktQty();
		double ratio = mktQty > 0 ? FPUtils.round2dp(getCumQty() / (double)mktStats.getMktQty()) : 0;
		logger.info("CumQty=" + cumQty + " MktQty=" + mktQty + " Ratio=" + ratio + "%");
		logger.info("Quote: " + depth.shortString());
		logger.info("On Market: " + LoggingUtils.logActiveChildOrders(order.getActiveChildOrders()));
	}

	public abstract StrategyPartition computeGoal();

}
