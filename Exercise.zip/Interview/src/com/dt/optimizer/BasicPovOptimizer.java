package com.dt.optimizer;

import java.util.Map;

import org.apache.commons.collections4.Predicate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.dt.TradeHistory;
import com.dt.core.IPrice;
import com.dt.core.Price;
import com.dt.core.Trade;
import com.dt.core.TradingMath;
import com.dt.core.orders.ClientOrder;
import com.dt.core.orders.IPartition;
import com.dt.core.orders.PartitionType;
import com.dt.core.orders.StrategyPartition;
import com.dt.tracking.CompositeTargetRatioFn;
import com.dt.tracking.PovVolumeTracking;

public class BasicPovOptimizer extends BasicQtyOptimizer {

	private static Logger logger = LogManager.getLogger(BasicPovOptimizer.class);

	private static double IDEAL_DEVIATION = 0.05;

	protected long idealCumQty, minCumQty, maxCumQty, clientMaxCumQty;
	protected PovVolumeTracking target;
	
	private ICatchupOptimizer catchup;
	private CompositeTargetRatioFn ratioFn;

	public BasicPovOptimizer(ClientOrder order) {
		super(order);
		catchup = new BookImbalanceCatchupOptimizer(isBuy);
		target = new Target(tradeFilter, tmath, getOrderQty());
		ratioFn = order.getCompositeTargetRatioFn();
	}
	
	public void updateCumQtys() {
		minCumQty = target.getMinCumQty();
		idealCumQty = target.getIdealCumQty();
		maxCumQty = getOrderQty();
		clientMaxCumQty = target.getClientMaxCumQty();
	}

	@Override
	protected void updateTradeListeners() {
		super.updateTradeListeners();
		TradeHistory.getInstance().updateListener(target, target.getLastTrade());
	}

	public void updateCachedValues() {
		updateCumQtys();
		logger.info("Min=" + minCumQty + " Ideal=" + idealCumQty + " Max=" + maxCumQty + " ClientMax="
				+ getClientMaxCumQty());
		catchup.update(depth);
	}

	public long getClientMaxCumQty() {
		return clientMaxCumQty;
	}

	protected void computeContGoal(StrategyPartition goal) {
		addAggressiveQtys(goal.getPartition(PartitionType.AGGRESSIVE));
		goal.confirmAggressiveAllocation();
		addPassiveQtys(goal.getPartition(PartitionType.PASSIVE));
	}

	// When crossing spread (below min)
	protected void addAggressiveQtys(IPartition part) {
		if (getClientMaxCumQty() > getCumQty() && minCumQty > getCumQty()) {
			long delta = Math.min(minCumQty - getCumQty(), getClientMaxCumQty() - getCumQty());
			logger.info("Cross to Min for " + delta);
			part.incr(Price.MARKET, delta);
		}
		addCatchupQtys(part);
	}

	// When we're trying to catch up to ideal
	protected void addCatchupQtys(IPartition part) {
		long catchupQty = idealCumQty - getCumQty() - part.getTotalQty();
		if (catchupQty > 0 && getClientMaxCumQty() > getCumQty()) {
			catchup.doCatchUp(part, Math.min(catchupQty, getClientMaxCumQty() - getCumQty()));
		}
	}

	protected void addPassiveQtys(IPartition part) {
		if (!part.isSendable()) {
			logger.info("No Passive Qty Left");
			return;
		}

		Map<IPrice, Long> passiveBook = isBuy ? depth.getBids() : depth.getAsks();
		logger.info("Price\t\tMarketQty\tTarget\t\tTarget%");
		for (IPrice price : passiveBook.keySet()) {
			if (beyondLimit(price))
				continue;
			long mktQty = passiveBook.get(price);
			long qty = tmath.roundDownLots(mktQty * getPassiveRatio(price));
			part.incr(price, qty);
			logger.info(price.getDoubleValue() + "\t\t" + mktQty + "\t\t" + qty + "\t\t" + getPassiveRatio(price));
		}

		part.roundQty();
	}

	// We can additionally add a Fn to reduce posting when we move further away
	// from near touch
	protected double getPassiveRatio(IPrice px) {
		return ratioFn.getTargetRatio(px);
	}

	@Override
	public StrategyPartition computeGoal() {
		StrategyPartition goal = new StrategyPartition(isBuy, maxCumQty);
		computeContGoal(goal);
		return goal;
	}

	private class Target extends PovVolumeTracking {
		public Target(Predicate<Trade> filter, TradingMath tmath, long orderQty) {
			super(filter, tmath, orderQty);
		}

		@Override
		protected double getMinRatio(IPrice px) {
			double minRatio = ratioFn.getMinRatio(px);
			if (minRatio > 0) {
				return minRatio;
			}
			return getIdealRatio(px) * (1 - IDEAL_DEVIATION);
		}

		@Override
		protected double getMaxRatio(IPrice px) {
			double maxRatio = getClientMaxRatio(px);
			if (maxRatio > 0) {
				return maxRatio;
			}
			return getIdealRatio(px) * (1 + IDEAL_DEVIATION);
		}

		@Override
		protected double getIdealRatio(IPrice px) {
			return ratioFn.getTargetRatio(px);
		}

		@Override
		protected double getClientMaxRatio(IPrice px) {
			return ratioFn.getMaxRatio(px);
		}
	}
}
