package com.dt.optimizer.utils;

import java.util.List;
import java.util.Map;

import com.dt.core.IPrice;
import com.dt.core.orders.IOrder;

public class LoggingUtils {

	public static String logActiveChildOrders(List<IOrder> children) {
		StringBuilder build = new StringBuilder();
		build.append("[ ");
		for (IOrder child : children) {
			double px = child.getPrice().getDoubleValue();
			build.append(px == 0 ? "MARKET" : px).append(":").append(child.getSize()).append(" ");
		}
		build.append("]");

		return build.toString();
	}
	
	public static String logStrategyGoal(Map<IPrice, Long> output) {
		StringBuilder build = new StringBuilder();
		build.append("[");
		for (IPrice price : output.keySet()) {
			double px = price.getDoubleValue();
			build.append(px == 0 ? "MARKET" : px).append(":").append(output.get(price)).append(" ");
		}
		build.append("]");
		return build.toString();
	}
}
