package com.dt.optimizer.utils;

public class FPUtils {
	public static double round2dp(double value) {
	    long factor = (long) Math.pow(10, 2);
	    value = value * factor;
	    long tmp = Math.round(value);
	    return (double) tmp / factor;
	}
}
