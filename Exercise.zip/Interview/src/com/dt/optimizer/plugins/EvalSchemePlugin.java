package com.dt.optimizer.plugins;

import com.dt.CurrentDepth;
import com.dt.core.IDepth;
import com.dt.core.IPrice;
import com.dt.core.Trade;

public class EvalSchemePlugin {

	private final static double BOOK_DIFFERENCE_FACTOR = 0.02;
	private BookDifference diff;

	public EvalSchemePlugin() {
		diff = new BookDifference(BOOK_DIFFERENCE_FACTOR);
	}

	public boolean wantToOptimize(IDepth depth) {
		return diff.bookHasChangedEnough(depth);
	}

	public boolean wantToOptimize(Trade trade) {
		// On the back of trades there should be a depth update. On this belief,
		// we shouldn't optimize on every trade. We should instead batch trades
		// together and optimize. For this exercise, we'll just optimize anyway
		return true;
	}

	private class BookDifference {
		// Event driven Algos can often go into loops especially so on a fast
		// moving market. Filtering out noise to prevent waste cpu cycles is
		// essential. This is a very simple implementation where it looks if any
		// of the following conditions are met will result in an evaluation
		// cycle. 1. Best Bid/Ask has changed 2. Best Bid/AskQty has changed
		// more than the specified factor. To build an even better mechanism, we
		// can look at layers down the book and assign different weight the
		// difference can carry

		private IDepth lastDepth = CurrentDepth.getSnapshot();
		private final double factor;

		protected BookDifference(double factor) {
			this.factor = factor;
		}

		public boolean bookHasChangedEnough(IDepth depth) {
			boolean result = false;

			if (lastDepth == null || priceHasChanged(lastDepth, depth) || quoteHasChangedEnough(lastDepth, depth)) {
				result = true;
			}

			lastDepth = depth;
			return result;

		}

		private boolean priceHasChanged(IDepth oldDepth, IDepth newDepth) {
			return priceHasChanged(oldDepth.getBestBid(), newDepth.getBestBid())
					|| priceHasChanged(oldDepth.getBestAsk(), newDepth.getBestAsk());
		}
		
		private boolean priceHasChanged(IPrice oldPx, IPrice newPx) {
			double oldVal = oldPx != null ? oldPx.getDoubleValue() : -1;
			double newVal = newPx != null ? newPx.getDoubleValue() : -1;
			
			return oldVal != newVal;
		}

		private boolean quoteHasChangedEnough(IDepth oldDepth, IDepth newDepth) {
			long oldQty = oldDepth.getBestAskSize() + oldDepth.getBestBidSize();
			long newQty = newDepth.getBestAskSize() + newDepth.getBestBidSize();
			long delta = Math.abs(oldQty - newQty);

			return oldQty * factor < delta;
		}

	}
}
