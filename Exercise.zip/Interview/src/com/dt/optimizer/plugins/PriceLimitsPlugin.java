package com.dt.optimizer.plugins;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.dt.core.IPrice;
import com.dt.core.TradingMath;
import com.dt.core.orders.ClientOrder;

public class PriceLimitsPlugin {

	private List<Range<IPrice>> limits;
	private TradingMath tmath;
	private boolean isBuy;

	public PriceLimitsPlugin(ClientOrder order, TradingMath tmath) {
		// We can add other limits like symbolic or relative to LTP limits for
		// example
		limits = new ArrayList<Range<IPrice>>();
		isBuy = order.isBuy();
		this.tmath = tmath;
		Range<IPrice> clientLmt = setupClientLimit(order);
		if (clientLmt != null) {
			limits.add(clientLmt);
		}
	}

	public IPrice getMaxAllowedPrice() {
		IPrice conservative = null;
		for (Range<IPrice> range : limits) {
			IPrice max = isBuy ? range.getMax() : range.getMin();
			if (conservative == null || max != null && tmath.priceIsPassive(max, conservative)) {
				conservative = max;
			}
		}

		return conservative;
	}

	public boolean adjustPrice(Map<IPrice, Long> output) {
		IPrice max = getMaxAllowedPrice();
		if (max == null)
			return false;
		long qtyToMove = 0;
		boolean hasRepriced = false;

		// First remove all qty from invalid prices
		for (IPrice price : output.keySet()) {
			long qty = output.get(price);
			if (tmath.priceIsAggressive(price, max)) {
				hasRepriced = true;
				qtyToMove += qty;
				output.put(price, 0L);
			} else if (tmath.priceIsPassiveOrEquals(price, max)) {
				break;
			}
		}

		// Simply collapse all to the max allowed price
		if (qtyToMove > 0) {
			Long qty = output.get(max);
			long existing = qty == null ? 0 : qty.longValue();
			output.put(max, qtyToMove + existing);
			qtyToMove = 0;

			// Remove any entries we have moved
			Iterator<Map.Entry<IPrice, Long>> iter = output.entrySet().iterator();
			while (iter.hasNext()) {
				Map.Entry<IPrice, Long> entry = iter.next();
				if (entry.getValue() == 0) {
					iter.remove();
				}
			}
		}

		return hasRepriced;
	}

	private Range<IPrice> setupClientLimit(ClientOrder order) {
		IPrice clientPx = order.getPrice();
		if (!clientPx.isMarket()) {
			IPrice min = isBuy ? null : clientPx;
			IPrice max = isBuy ? clientPx : null;
			return new Range<IPrice>(min, max);
		}

		return null;
	}

	private class Range<T> {
		private T min, max;

		public Range(T min, T max) {
			this.max = max;
			this.min = min;
		}

		public T getMax() {
			return max;
		}

		public T getMin() {
			return min;
		}
	}
}
