package com.dt.optimizer;

import java.time.LocalTime;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.dt.ClockManager;
import com.dt.core.DayTiming;
import com.dt.core.IPrice;
import com.dt.core.orders.ClientOrder;
import com.dt.curve.IdealQtyAtTimeFn;
import com.dt.curve.MaxQtyAtTimeFn;
import com.dt.curve.MinQtyAtTimeFn;
import com.dt.optimizer.utils.FPUtils;

public class QtyCurveOptimizer extends BasicPovOptimizer {

	private static Logger logger = LogManager.getLogger(QtyCurveOptimizer.class);

	private final IdealQtyAtTimeFn idealCumQtyFn;
	private final MinQtyAtTimeFn minQtyFn;
	private final MaxQtyAtTimeFn maxQtyFn;

	private double idealTargetRatio;
	
	private boolean hasTargets;

	public QtyCurveOptimizer(ClientOrder order) {
		super(order);
		
		hasTargets = !order.getCompositeTargetRatioFn().isEmpty();
		
		idealCumQtyFn = new IdealQtyAtTimeFn(order.getSize(), stats, order.getStartTime());
		minQtyFn = new MinQtyAtTimeFn(idealCumQtyFn, order.getSize());
		maxQtyFn = new MaxQtyAtTimeFn(idealCumQtyFn, stats);

		LocalTime t = order.getStartTime();
		LocalTime end = order.getEndTime();
		logger.debug("Time\t\tMin\t\tIdeal\t\tMax");
		for (int i = 0; !t.plusMinutes(i).isAfter(end); i++) {
			LocalTime current = t.plusMinutes(i);
			logger.debug(current + "\t\t" + FPUtils.round2dp(minQtyFn.valueFor(current)) + "\t\t"
					+ FPUtils.round2dp(idealCumQtyFn.valueFor(current)) + "\t\t"
					+ FPUtils.round2dp(maxQtyFn.valueFor(current)));
		}
	}

	@Override
	public void updateCumQtys() {
		maxCumQty = tmath.roundDownLots(maxQtyFn.valueFor(now));
		idealCumQty = tmath.roundDownLots(idealCumQtyFn.valueFor(now));
		minCumQty = tmath.roundDownLots(minQtyFn.valueFor(now));
		clientMaxCumQty = hasTargets ? target.getClientMaxCumQty() : getOrderQty();
	}
	
	@Override
	public void updateCachedValues() {
		super.updateCachedValues();
		idealTargetRatio = Math.min(1.0, (getOrderQty() - getCumQty())
				/ getPredictor().getPredictedQty(ClockManager.getTime(), DayTiming.DAY_END_TIME));
	}

	@Override
	protected double getPassiveRatio(IPrice px) {
		return Math.max(FPUtils.round2dp(idealTargetRatio), super.getPassiveRatio(px));
	}
}
