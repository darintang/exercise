package com.dt.optimizer;

import java.util.Map;

import com.dt.core.IDepth;
import com.dt.core.IPrice;
import com.dt.core.Trade;

public interface IOptimizer {
	public Map<IPrice, Long> optimize(IEvalContext ctx);
	public boolean wantToOptimize(IDepth depth);
	public boolean wantToOptimize(Trade trade);
}
