package com.dt.optimizer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.dt.core.IDepth;
import com.dt.core.IPrice;
import com.dt.core.orders.IPartition;

public class BookImbalanceCatchupOptimizer implements ICatchupOptimizer {

	private static final Logger LOGGER = LogManager.getLogger(BookImbalanceCatchupOptimizer.class);
	private static final double IMBALANCE_FACTOR = 0.5;

	private IDepth depth;
	private boolean isBuy;

	public BookImbalanceCatchupOptimizer(boolean isBuy) {
		this.isBuy = isBuy;
	}

	/**
	 * A very simple model that tries to detect book imbalance where the market
	 * is likely to move away. If it is not the case, we'll stack more qty on
	 * near touch in hope that someone will lift us
	 * 
	 * @return
	 */
	@Override
	public boolean shouldCatchup() {
		if (depth.getBestAsk() == null || depth.getBestBid() == null)
			return false;

		return depth.getBestSize(!isBuy) <= depth.getBestSize(isBuy) * IMBALANCE_FACTOR;
	}

	@Override
	public void update(IDepth depth) {
		this.depth = depth;
	}

	@Override
	public void doCatchUp(IPartition part, long qty) {
		IPrice price = depth.getBestPrice(isBuy);
		if (shouldCatchup()) {
			LOGGER.info("Cross to Catchup for " + qty);
			price = depth.getBestPrice(!isBuy);
		}

		part.incr(price, qty);
	}
}
