package com.dt.optimizer;

import com.dt.core.IDepth;

public interface IDepthDependentPlugins {
	public void update(IDepth depth);
}
