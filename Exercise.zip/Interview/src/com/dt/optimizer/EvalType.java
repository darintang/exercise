package com.dt.optimizer;

public enum EvalType {
	Normal, FullReset;
}
