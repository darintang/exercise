package com.dt.optimizer;

import java.time.LocalTime;

import com.dt.core.IDepth;

public interface IEvalContext {
	public IDepth getDepth();
	public LocalTime getTime();
}
