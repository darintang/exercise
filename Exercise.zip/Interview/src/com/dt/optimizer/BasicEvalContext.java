package com.dt.optimizer;

import java.time.LocalTime;

import com.dt.core.IDepth;

public class BasicEvalContext implements IEvalContext {

	@SuppressWarnings("unused")
	private final EvalType type;
	private final IDepth depth;
	private final LocalTime time;
	
	public BasicEvalContext(EvalType type, IDepth depth, LocalTime time) {
		this.type = type;
		this.depth = depth;
		this.time = time;
	}
	
	@Override
	public IDepth getDepth() {
		return depth;
	}

	@Override
	public LocalTime getTime() {
		return time;
	}
}