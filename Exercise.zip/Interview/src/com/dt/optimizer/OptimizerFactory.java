package com.dt.optimizer;

import com.dt.core.TradingStrategy;
import com.dt.core.orders.ClientOrder;

public class OptimizerFactory {

	public static IOptimizer createOptimizer(ClientOrder order) throws Exception {
		TradingStrategy strategy = order.getTradingStrategy();

		switch (strategy) {
		case VWAP:
			return new QtyCurveOptimizer(order);
		case POV:
			return new BasicPovOptimizer(order);
		default:
			throw new Exception("Unsupported Strategy");
		}
	}
}
