package com.dt;

import java.time.LocalTime;
import java.util.Map;

import org.apache.commons.collections4.Predicate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.dt.core.Event;
import com.dt.core.IDepth;
import com.dt.core.IDepthListener;
import com.dt.core.IEventListener;
import com.dt.core.IPrice;
import com.dt.core.ITradeListener;
import com.dt.core.Trade;
import com.dt.core.orders.ClientOrder;
import com.dt.core.orders.OrdersAllocator;
import com.dt.optimizer.BasicEvalContext;
import com.dt.optimizer.EvalType;
import com.dt.optimizer.IOptimizer;
import com.dt.optimizer.OptimizerFactory;

public class EvalStrategy implements ITradeListener, IDepthListener, IEventListener {

	private static Logger logger = LogManager.getLogger(EvalStrategy.class);

	private IOptimizer optimizer;
	private IDepth lastDepth;
	private int evalCount;
	private ClientOrder order;
	private OrdersAllocator allocator;

	private final Predicate<IDepth> bookValidation;

	public EvalStrategy() {
		allocator = new OrdersAllocator();
		bookValidation = new BookValidatorPredicate();
	}

	public void onInit(ClientOrder order) throws Exception {
		this.order = order;
		optimizer = OptimizerFactory.createOptimizer(order);
		lastDepth = CurrentDepth.getSnapshot();
		addCompletionEvals();
		logger.info("Strategy inputs: " + order.logOrder());
		evaluate(EvalType.FullReset);
	}

	/**
	 * Ensure that we will have some evaluates before the order end time to
	 * facilitate completion. We can obviously add this through the lifespan as
	 * well to handle illiquid names.
	 */
	private void addCompletionEvals() {
		LocalTime end = order.getEndTime();

		for (int i = 1; i <= 3; i++) {
			ClockManager.addEvent(end.minusSeconds(i * 5));
		}
	}

	public void onDepth(IDepth depth) {
		lastDepth = depth;
		logger.debug("onDepth: " + depth.shortString());
		if (!bookValidation.evaluate(depth))
			return;

		if (optimizer.wantToOptimize(depth)) {
			evaluate(EvalType.Normal);
		} else {
			logger.debug("Depth hasn't changed much.");
		}
			
	}

	@Override
	public void onTrade(Trade trade) {
		// Should batch trades and evaluate on the next available depth
		logger.debug("onTrade: " + trade.shortString());
	}

	@Override
	public void onEvent(Event event) {
		evaluate(EvalType.Normal);
	}

	private void evaluate(EvalType type) {
		BasicEvalContext ctx = new BasicEvalContext(type, lastDepth, ClockManager.getTime());
		++evalCount;
		logger.info("========== Evaluate #" + evalCount + " (" + type + ") ==========");
		Map<IPrice, Long> output = optimizer.optimize(ctx);
		allocator.allocate(order.getActiveChildOrders(), output);
		logger.info("========== End Evaluate #" + evalCount + " ==========");
	}

	private class BookValidatorPredicate implements Predicate<IDepth> {
		@Override
		public boolean evaluate(IDepth depth) {
			final IPrice bidPx = depth.getBestBid();
			final IPrice askPx = depth.getBestAsk();
			if (bidPx != null && askPx != null) {
				double bid = bidPx.getDoubleValue();
				double ask = askPx.getDoubleValue();
				if (bid == ask || bid > ask) {
					logger.debug("Crossed/Locked Book observe. Skip Evaluate");
					return false;
				}
				return true;
			}

			return false;
		}
	}
}
