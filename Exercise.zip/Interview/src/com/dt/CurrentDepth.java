package com.dt;

import com.dt.core.IDepth;
import com.dt.core.IDepthListener;

public class CurrentDepth implements IDepthListener {

	// This to basically simulate a market data connection that helps to
	// retrieves the last snapshot of depth available. We wouldnt need this but
	// an actual resource if we were to implement it

	private static CurrentDepth instance = null;
	protected CurrentDepth() {

	}
	
	public static CurrentDepth getInstance() {
		if (instance == null) {
			instance = new CurrentDepth();
		}
		return instance;
	}
	
	private static IDepth snapshot;
	
	@Override
	public void onDepth(IDepth depth) {
		CurrentDepth.updateSnapshot(depth);
	}
	
	public static void updateSnapshot(IDepth depth) {
		snapshot = depth;
	}
	
	public static IDepth getSnapshot() {
		return snapshot;
	}

}
