package com.dt.tracking;

import org.apache.commons.collections4.Predicate;

import com.dt.core.ITradeListener;
import com.dt.core.Trade;

public class MarketVolumeTracker implements ITradeListener {

	private Predicate<Trade> filter;
	private Trade lastTrade;

	protected long qty;

	public MarketVolumeTracker(Predicate<Trade> filter) {
		this.filter = filter;
	}

	@Override
	public void onTrade(Trade trade) {
		if (shouldProcessTrade(trade)) {
			processTrade(trade);
		}
	}

	protected void processTrade(Trade trade) {
		qty += trade.getSize();
	}
	
	protected boolean shouldProcessTrade(Trade trade) {
		lastTrade = trade;
		return filter == null || filter.evaluate(trade);
	}
	
	public long getMktQty() {
		return qty;
	}
	
	public Trade getLastTrade() {
		return lastTrade;
	}

}
