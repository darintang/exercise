package com.dt.tracking;

import org.apache.commons.collections4.Predicate;

import com.dt.core.IPrice;
import com.dt.core.Trade;
import com.dt.core.TradingMath;

public abstract class PovVolumeTracking extends MarketVolumeTracker {

	private long minCumQty, idealCumQty, maxCumQty, clientMaxCumQty, orderQty;

	private TradingMath tmath;

	public PovVolumeTracking(Predicate<Trade> filter, TradingMath tmath, long orderQty) {
		super(filter);
		this.tmath = tmath;
		this.orderQty = orderQty;
	}

	@Override
	protected void processTrade(Trade trade) {
		super.processTrade(trade);

		minCumQty += Math.min(tmath.roundDownLots(trade.getSize() * getMinRatio(trade.getPrice())), orderQty);
		idealCumQty += Math.min(tmath.roundDownLots(trade.getSize() * getIdealRatio(trade.getPrice())), orderQty);
		maxCumQty += Math.min(tmath.roundDownLots(trade.getSize() * getMaxRatio(trade.getPrice())), orderQty);

		double clientMax = getClientMaxRatio(trade.getPrice());
		if (clientMax > 0) {
			clientMaxCumQty += Math.min(tmath.roundDownLots(trade.getSize() * getClientMaxRatio(trade.getPrice())), orderQty);
		} else {
			clientMaxCumQty = orderQty;
		}
	}
	
	public long getMinCumQty() {
		return minCumQty;
	}
	
	public long getMaxCumQty() {
		return maxCumQty;
	}
	
	public long getIdealCumQty() {
		return idealCumQty;
	}
	
	public long getClientMaxCumQty() {
		return clientMaxCumQty;
	}

	protected abstract double getMinRatio(IPrice px);

	protected abstract double getMaxRatio(IPrice px);

	protected abstract double getIdealRatio(IPrice px);

	protected abstract double getClientMaxRatio(IPrice px);
}
