package com.dt.tracking;

import com.dt.core.IPrice;

public class TargetRatioFn implements ITargetRatioFn {

	private double min,ideal,max;
	
	public TargetRatioFn(double min, double ideal, double max) {
		this.min = min;
		this.max = max;
		this.ideal = ideal;
	}

	@Override
	public double getTargetRatio(IPrice px) {
		return ideal;
	}
	
	@Override
	public double getMinRatio(IPrice px) {
		return min;
	}
	
	@Override
	public double getMaxRatio(IPrice px) {
		return max;
	}
}
