package com.dt.tracking;

import org.apache.commons.collections4.Predicate;

import com.dt.core.IPrice;
import com.dt.core.Trade;
import com.dt.core.TradingMath;

public class TradeFilter implements Predicate<Trade>{

	private IPrice px;
	private TradingMath tmath;
	
	public TradeFilter(IPrice px, TradingMath tmath) {
		this.px = px;
		this.tmath = tmath;
	}
	
	@Override
	public boolean evaluate(Trade trade) {
		return tmath.priceIsPassiveOrEquals(trade.getPrice(), px);
	}

}
