package com.dt.tracking;

import com.dt.core.IPrice;

public interface ITargetRatioFn {

	public double getTargetRatio(IPrice px);
	
	public double getMinRatio(IPrice px);
	
	public double getMaxRatio(IPrice px);
}
