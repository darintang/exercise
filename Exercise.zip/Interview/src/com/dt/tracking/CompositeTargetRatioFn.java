package com.dt.tracking;

import java.util.Map.Entry;
import java.util.TreeMap;

import com.dt.core.IPrice;
import com.dt.core.TradingMath;

public class CompositeTargetRatioFn implements ITargetRatioFn {

	private TreeMap<IPrice, ITargetRatioFn> targets;
	private TradingMath tmath;

	public CompositeTargetRatioFn(boolean isBuy, TradingMath tmath) {
		targets = new TreeMap<IPrice, ITargetRatioFn>(isBuy ? TradingMath.SELL_COMP : TradingMath.BUY_COMP);
		this.tmath = tmath;
	}
	
	public void addTarget(IPrice px, ITargetRatioFn target) {
		targets.put(px, target);
	}

	@Override
	public double getTargetRatio(IPrice px) {
		Entry<IPrice, ITargetRatioFn> entry = targets.ceilingEntry(px);
		if (entry != null && tmath.priceIsPassiveOrEquals(px, entry.getKey())) {
			return entry.getValue().getTargetRatio(px);
		} else if (entry == null && !targets.isEmpty()) {
			entry = targets.firstEntry();
			return tmath.priceIsPassiveOrEquals(px, entry.getKey()) ? entry.getValue().getTargetRatio(px) : 0;
		}
		return 0;
	}

	@Override
	public double getMinRatio(IPrice px) {
		Entry<IPrice, ITargetRatioFn> entry = targets.ceilingEntry(px);
		if (entry != null && tmath.priceIsPassiveOrEquals(px, entry.getKey())) {
			return entry.getValue().getMinRatio(px);
		} else if (entry == null && !targets.isEmpty()) {
			entry = targets.firstEntry();
			return tmath.priceIsPassiveOrEquals(px, entry.getKey()) ? entry.getValue().getMinRatio(px) : 0;
		}
		return 0;
	}

	@Override
	public double getMaxRatio(IPrice px) {
		Entry<IPrice, ITargetRatioFn> entry = targets.ceilingEntry(px);
		if (entry != null && tmath.priceIsPassiveOrEquals(px, entry.getKey())) {
			return entry.getValue().getMaxRatio(px);
		} else if (entry == null && !targets.isEmpty()) {
			entry = targets.firstEntry();
			return tmath.priceIsPassiveOrEquals(px, entry.getKey()) ? entry.getValue().getMaxRatio(px) : 0;
		}
		return 0;
	}
	
	public boolean isEmpty() {
		return targets.isEmpty();
	}
}
