package com.dt.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Map;
import java.util.TreeMap;

import com.dt.core.IDepth;
import com.dt.core.IPrice;
import com.dt.core.MarketDepth;
import com.dt.core.Price;
import com.dt.core.TradingMath;

public class TestUtils {

	public static Price PX_99 = new Price(99);
	public static Price PX_100 = new Price(100);
	public static Price PX_101 = new Price(101);
	public static Price PX_102 = new Price(102);
	
	public static IDepth createDepth(IPrice bid, long bidQty, IPrice ask, long askQty) {
		TreeMap<IPrice, Long> bidMap = new TreeMap<IPrice, Long>(TradingMath.BUY_COMP);
		TreeMap<IPrice, Long> askMap = new TreeMap<IPrice, Long>(TradingMath.SELL_COMP);
		if (bid != null)
			bidMap.put(bid, bidQty);
		if (ask!=null)
			askMap.put(ask, askQty);
		return new MarketDepth(bidMap, askMap);
	}
	
	public static void assertSameMap(Map<IPrice, Long> input, Map<IPrice, Long> expect) {
		assertTrue(input.size() == expect.size());
		for (IPrice px : input.keySet()) {
			assertEquals(input.get(px), expect.get(px));
		}
		
		for (IPrice px : expect.keySet()) {
			assertEquals(input.get(px), expect.get(px));
		}
	}
}
