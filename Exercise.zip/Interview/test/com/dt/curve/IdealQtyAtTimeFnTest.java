package com.dt.curve;

import static org.junit.Assert.*;

import org.junit.Test;

import com.dt.core.DayTiming;
import com.dt.core.Stats;

public class IdealQtyAtTimeFnTest {
	@Test
	public void testCurveIncrementing() {
		IdealQtyAtTimeFn ideal = new IdealQtyAtTimeFn(10000, new Stats(), DayTiming.DAY_START_TIME);
		
		double prev = 0;
		for (int i=0; !DayTiming.DAY_START_TIME.plusSeconds(i).isAfter(DayTiming.DAY_END_TIME); i++) {
			double current = ideal.valueFor(DayTiming.DAY_START_TIME.plusSeconds(i));
			assertTrue( current >= prev);
			prev = current;
		}
	}

}
