package com.dt.curve;

import static org.junit.Assert.*;

import org.junit.Test;

import com.dt.core.DayTiming;
import com.dt.core.Stats;

public class MaxQtyAtTimeFnTest {

	@Test
	public void testCurveIncrementing() {
		IdealQtyAtTimeFn ideal = new IdealQtyAtTimeFn(10000, new Stats(), DayTiming.DAY_START_TIME);
		MaxQtyAtTimeFn max = new MaxQtyAtTimeFn(ideal, new Stats());

		double prev = 0;
		for (int i = 0; !DayTiming.DAY_START_TIME.plusSeconds(i).isAfter(DayTiming.DAY_END_TIME); i++) {
			double current = max.valueFor(DayTiming.DAY_START_TIME.plusSeconds(i));
			double idealQty = ideal.valueFor(DayTiming.DAY_START_TIME.plusSeconds(i + 50));
			assertTrue(current >= prev);
			assertEquals(current, idealQty, 0);
			prev = current;
		}
	}

}
