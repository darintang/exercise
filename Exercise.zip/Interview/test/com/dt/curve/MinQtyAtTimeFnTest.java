package com.dt.curve;

import static org.junit.Assert.*;

import org.junit.Test;

import com.dt.core.DayTiming;
import com.dt.core.Stats;

public class MinQtyAtTimeFnTest {

	@Test
	public void testCurveIncrementing() {
		IdealQtyAtTimeFn ideal = new IdealQtyAtTimeFn(10000, new Stats(), DayTiming.DAY_START_TIME);
		MinQtyAtTimeFn min = new MinQtyAtTimeFn(ideal, 10000);
		
		double prev = 0;
		for (int i=0; !DayTiming.DAY_START_TIME.plusSeconds(i).isAfter(DayTiming.DAY_END_TIME); i++) {
			double current = min.valueFor(DayTiming.DAY_START_TIME.plusSeconds(i));
			double idealQty = ideal.valueFor(DayTiming.DAY_START_TIME.plusSeconds(i));
			assertTrue( current >= prev);
			if (idealQty >= 9500) {
				assertEquals(current, idealQty, 0);
			}
			prev = current;
		}
	}
}
