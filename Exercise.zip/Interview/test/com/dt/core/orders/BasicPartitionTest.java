package com.dt.core.orders;

import static org.junit.Assert.*;

import org.junit.Test;

import com.dt.core.Price;

public class BasicPartitionTest {

	@Test
	public void testRoundQtyHonorMax() {
		assertRoundQtyHonorMax(true, PartitionType.AGGRESSIVE);
		assertRoundQtyHonorMax(false, PartitionType.AGGRESSIVE);
		assertRoundQtyHonorMax(true, PartitionType.PASSIVE);
		assertRoundQtyHonorMax(false, PartitionType.PASSIVE);
	}
	
	private void assertRoundQtyHonorMax(boolean isBuy, PartitionType type) {
		BasicPartition part = new BasicPartition(isBuy, type, 1000);
		part.incr(Price.MARKET, 100);
		part.roundQty();
		assertTrue(part.getTotalQty() == 100);
		
		part = new BasicPartition(isBuy, type, 1000);
		part.incr(Price.MARKET, 1000);
		part.roundQty();
		assertTrue(part.getTotalQty() == 1000);
		
		part = new BasicPartition(isBuy, type, 1000);
		part.incr(Price.MARKET, 1100);
		part.roundQty();
		assertTrue(part.getTotalQty() == 1000);
	}

}
