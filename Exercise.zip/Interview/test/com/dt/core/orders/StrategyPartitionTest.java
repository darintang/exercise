package com.dt.core.orders;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.dt.core.IPrice;
import com.dt.core.Price;
import com.dt.utils.TestUtils;

public class StrategyPartitionTest {

	@Test
	public void testConfirmPartition() {
		StrategyPartition part = new StrategyPartition(true, 1000);
		part.getPartition(PartitionType.AGGRESSIVE).incr(Price.MARKET, 900);
		part.confirmAggressiveAllocation();
		part.getPartition(PartitionType.PASSIVE).incr(Price.MARKET, 900);
		part.getPartition(PartitionType.PASSIVE).roundQty();
		
		assertTrue(part.getPartition(PartitionType.AGGRESSIVE).getTotalQty() == 900);
		assertTrue(part.getPartition(PartitionType.PASSIVE).getTotalQty() == 100);
		
		part = new StrategyPartition(true, 1000);
		part.getPartition(PartitionType.AGGRESSIVE).incr(Price.MARKET, 900);
		part.getPartition(PartitionType.AGGRESSIVE).incr(new Price(100), 0);
		part.confirmAggressiveAllocation();
		part.getPartition(PartitionType.PASSIVE).incr(Price.MARKET, 900);
		part.getPartition(PartitionType.PASSIVE).roundQty();
		
		assertTrue(part.getPartition(PartitionType.AGGRESSIVE).getTotalQty() == 900);
		assertTrue(part.getPartition(PartitionType.PASSIVE).getTotalQty() == 100);
		
		part = new StrategyPartition(true, 1000);
		part.getPartition(PartitionType.AGGRESSIVE).incr(Price.MARKET, 400);
		part.getPartition(PartitionType.AGGRESSIVE).incr(new Price(100), 500);
		part.confirmAggressiveAllocation();
		part.getPartition(PartitionType.PASSIVE).incr(Price.MARKET, 900);
		part.getPartition(PartitionType.PASSIVE).roundQty();
		
		assertTrue(part.getPartition(PartitionType.AGGRESSIVE).getTotalQty() == 900);
		assertTrue(part.getPartition(PartitionType.PASSIVE).getTotalQty() == 100);
		
		part = new StrategyPartition(true, 1000);
		part.getPartition(PartitionType.AGGRESSIVE).incr(Price.MARKET, 500);
		part.getPartition(PartitionType.AGGRESSIVE).incr(new Price(100), 500);
		part.confirmAggressiveAllocation();
		part.getPartition(PartitionType.PASSIVE).incr(Price.MARKET, 900);
		part.getPartition(PartitionType.PASSIVE).roundQty();
		
		assertTrue(part.getPartition(PartitionType.AGGRESSIVE).getTotalQty() == 1000);
		assertTrue(part.getPartition(PartitionType.PASSIVE).getTotalQty() == 0);
		
		part = new StrategyPartition(true, 1000);
		part.confirmAggressiveAllocation();
		part.getPartition(PartitionType.PASSIVE).incr(Price.MARKET, 900);
		part.getPartition(PartitionType.PASSIVE).roundQty();
		
		assertTrue(part.getPartition(PartitionType.AGGRESSIVE).getTotalQty() == 0);
		assertTrue(part.getPartition(PartitionType.PASSIVE).getTotalQty() == 900);
	}
	
	@Test
	public void testMergePartition() {
		final IPrice PX_100 = new Price(100);
		Map<IPrice, Long> merge;
		Map<IPrice, Long> expected = new HashMap<IPrice, Long>();
		StrategyPartition part = new StrategyPartition(true, 1000);
		part.getPartition(PartitionType.AGGRESSIVE).incr(Price.MARKET, 900);
		part.confirmAggressiveAllocation();
		part.getPartition(PartitionType.PASSIVE).incr(Price.MARKET, 900);
		part.getPartition(PartitionType.PASSIVE).roundQty();

		merge = part.mergePartitions();
		expected.put(Price.MARKET, 1000L); 
		TestUtils.assertSameMap(merge, expected);
		
		part = new StrategyPartition(true, 1000);
		part.getPartition(PartitionType.AGGRESSIVE).incr(Price.MARKET, 400);
		part.getPartition(PartitionType.AGGRESSIVE).incr(PX_100, 500);
		part.confirmAggressiveAllocation();
		part.getPartition(PartitionType.PASSIVE).incr(Price.MARKET, 900);
		part.getPartition(PartitionType.PASSIVE).roundQty();

		merge = part.mergePartitions();
		expected.clear();
		expected.put(Price.MARKET, 500L); 
		expected.put(PX_100, 500L);
		TestUtils.assertSameMap(merge, expected);
		
		part = new StrategyPartition(true, 1000);
		part.getPartition(PartitionType.AGGRESSIVE).incr(Price.MARKET, 100);
		part.getPartition(PartitionType.AGGRESSIVE).incr(PX_100, 500);
		part.confirmAggressiveAllocation();
		part.getPartition(PartitionType.PASSIVE).incr(PX_100, 900);
		part.getPartition(PartitionType.PASSIVE).roundQty();

		merge = part.mergePartitions();
		expected.clear();
		expected.put(Price.MARKET, 100L); 
		expected.put(PX_100, 900L);
		TestUtils.assertSameMap(merge, expected);
	}
}
