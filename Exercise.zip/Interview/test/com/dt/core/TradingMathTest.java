package com.dt.core;

import static org.junit.Assert.*;

import org.junit.Test;

public class TradingMathTest {

	private static Price PX_100 = new Price(100);
	private static Price PX_101 = new Price(101);
	
	@Test
	public void testPriceComparison() {
		TradingMath tmathBuy = new TradingMath(true, new Instrument());
		TradingMath tmathSell = new TradingMath(false, new Instrument());
		
		assertFalse(tmathBuy.priceIsAggressive(PX_100, PX_101));
		assertTrue(tmathSell.priceIsAggressive(PX_100, PX_101));
		assertFalse(tmathBuy.priceIsAggressiveOrEquals(PX_100, PX_101));
		assertTrue(tmathSell.priceIsAggressiveOrEquals(PX_100, PX_101));
		
		assertTrue(tmathBuy.priceIsAggressiveOrEquals(PX_100, PX_100));
		assertTrue(tmathSell.priceIsAggressiveOrEquals(PX_100, PX_100));
		assertTrue(tmathBuy.priceIsPassiveOrEquals(PX_100, PX_100));
		assertTrue(tmathSell.priceIsPassiveOrEquals(PX_100, PX_100));
		
		assertTrue(tmathBuy.priceIsPassive(PX_100, PX_101));
		assertFalse(tmathSell.priceIsPassive(PX_100, PX_101));
		assertTrue(tmathBuy.priceIsPassiveOrEquals(PX_100, PX_101));
		assertFalse(tmathSell.priceIsPassiveOrEquals(PX_100, PX_101));
	}

}
