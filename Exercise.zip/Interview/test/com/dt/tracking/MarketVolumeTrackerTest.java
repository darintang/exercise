package com.dt.tracking;

import static org.junit.Assert.*;

import org.junit.Test;

import com.dt.core.DayTiming;
import com.dt.core.Instrument;
import com.dt.core.Price;
import com.dt.core.Trade;
import com.dt.core.TradingMath;
import com.dt.utils.TestUtils;

public class MarketVolumeTrackerTest {

	private static Trade TRADE_99 = new Trade(TestUtils.PX_99, 1000, DayTiming.DAY_START_TIME);
	private static Trade TRADE_100 = new Trade(TestUtils.PX_100, 1000, DayTiming.DAY_START_TIME);
	
	@Test
	public void testTracking() {
		MarketVolumeTracker track = new MarketVolumeTracker(new TradeFilter(Price.MARKET, new TradingMath(true, new Instrument())));
		track.onTrade(TRADE_100);
		track.onTrade(TRADE_99);
		assertEquals(track.getMktQty(), 2000);
		
		track = new MarketVolumeTracker(new TradeFilter(TestUtils.PX_99, new TradingMath(true, new Instrument())));
		track.onTrade(TRADE_100);
		track.onTrade(TRADE_99);
		assertEquals(track.getMktQty(), 1000);
	}

}
