package com.dt.tracking;

import static org.junit.Assert.*;

import org.junit.Test;

import com.dt.core.DayTiming;
import com.dt.core.Instrument;
import com.dt.core.Price;
import com.dt.core.Trade;
import com.dt.core.TradingMath;
import com.dt.utils.TestUtils;

public class TradeFilterTest {

	@Test
	public void testFilter() {
		TradeFilter filter = new TradeFilter(Price.MARKET, new TradingMath(true, new Instrument()));
		assertTrue(filter.evaluate(new Trade(TestUtils.PX_100, 1000, DayTiming.DAY_START_TIME)));
		
		filter = new TradeFilter(TestUtils.PX_100, new TradingMath(true, new Instrument()));
		assertTrue(filter.evaluate(new Trade(TestUtils.PX_100, 1000, DayTiming.DAY_START_TIME)));
		assertTrue(filter.evaluate(new Trade(TestUtils.PX_99, 1000, DayTiming.DAY_START_TIME)));
		assertFalse(filter.evaluate(new Trade(TestUtils.PX_101, 1000, DayTiming.DAY_START_TIME)));
		
		filter = new TradeFilter(TestUtils.PX_100, new TradingMath(false, new Instrument()));
		assertTrue(filter.evaluate(new Trade(TestUtils.PX_100, 1000, DayTiming.DAY_START_TIME)));
		assertFalse(filter.evaluate(new Trade(TestUtils.PX_99, 1000, DayTiming.DAY_START_TIME)));
		assertTrue(filter.evaluate(new Trade(TestUtils.PX_101, 1000, DayTiming.DAY_START_TIME)));
	}

}
