package com.dt.optimizer;
import static org.junit.Assert.*;

import java.time.LocalTime;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.dt.ClockManager;
import com.dt.core.IPrice;
import com.dt.core.Instrument;
import com.dt.core.Price;
import com.dt.core.TradingStrategy;
import com.dt.core.orders.ClientOrder;
import com.dt.optimizer.BasicEvalContext;
import com.dt.optimizer.EvalType;
import com.dt.optimizer.QtyCurveOptimizer;
import com.dt.utils.TestUtils;

public class QtyCurveOptimizerTest {

	@Before
	public void setup() {
		ClockManager.setNow(LocalTime.parse("09:00"));
	}
	
	@Test
	public void testMaxCurveRestrictPosting() {
		ClientOrder order = new ClientOrder(true, new Instrument(), Price.MARKET, 10000, TradingStrategy.VWAP);
		QtyCurveOptimizer opt = new QtyCurveOptimizer(order);
		BasicEvalContext ctx = new BasicEvalContext(EvalType.Normal, TestUtils.createDepth(TestUtils.PX_100, 1000, TestUtils.PX_101, 1000), ClockManager.getTime());

		// 11% passively
		Map<IPrice, Long> goal = opt.optimize(ctx);
		assertEquals(110L, (long)goal.get(TestUtils.PX_100));
		
		// 11% more than max curve, so capped
		ctx = new BasicEvalContext(EvalType.Normal, TestUtils.createDepth(TestUtils.PX_100, 5000, TestUtils.PX_101, 5000), ClockManager.getTime());
		goal = opt.optimize(ctx);
		assertEquals(417L, (long)goal.get(TestUtils.PX_100));
	}
	
	@Test
	public void testMinCurveCrossing() {
		ClockManager.setNow(LocalTime.parse("09:10"));
		
		ClientOrder order = new ClientOrder(true, new Instrument(), Price.MARKET, 10000, TradingStrategy.VWAP);
		QtyCurveOptimizer opt = new QtyCurveOptimizer(order);
		BasicEvalContext ctx = new BasicEvalContext(EvalType.Normal, TestUtils.createDepth(TestUtils.PX_100, 1000, TestUtils.PX_101, 1000), ClockManager.getTime());

		Map<IPrice, Long> goal = opt.optimize(ctx);
		assertEquals(561L, (long)goal.get(Price.MARKET));
		assertEquals(139L, (long)goal.get(TestUtils.PX_100));
	}
}
