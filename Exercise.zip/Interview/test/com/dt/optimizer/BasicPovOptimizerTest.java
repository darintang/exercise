package com.dt.optimizer;

import static org.junit.Assert.*;

import java.time.LocalTime;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;

import com.dt.ClockManager;
import com.dt.TradeHistory;
import com.dt.core.DayTiming;
import com.dt.core.IDepth;
import com.dt.core.IPrice;
import com.dt.core.Instrument;
import com.dt.core.MarketDepth;
import com.dt.core.Trade;
import com.dt.core.TradingMath;
import com.dt.core.TradingStrategy;
import com.dt.core.orders.ClientOrder;
import com.dt.tracking.TargetRatioFn;
import com.dt.utils.TestUtils;

public class BasicPovOptimizerTest {

	private IDepth depth = null;
	
	@Before
	public void setup() {
		ClockManager.setNow(LocalTime.parse("09:00"));
		
		TreeMap<IPrice, Long> bidMap = new TreeMap<IPrice, Long>(TradingMath.BUY_COMP);
		TreeMap<IPrice, Long> askMap = new TreeMap<IPrice, Long>(TradingMath.SELL_COMP);
		bidMap.put(TestUtils.PX_100, 1000L);
		bidMap.put(TestUtils.PX_99, 1000L);
		askMap.put(TestUtils.PX_101, 1000L);
	
		depth = new MarketDepth(bidMap, askMap);
	}
	
	@Test
	public void testVolumeTracking() {
		ClientOrder order = new ClientOrder(true, new Instrument(), TestUtils.PX_101, 10000, TradingStrategy.POV);
		TargetRatioFn target = new TargetRatioFn(0.03, 0.05, 0);
		order.addTargetRatioFn(TestUtils.PX_101, target);
		
		BasicPovOptimizer opt = new BasicPovOptimizer(order);
		BasicEvalContext ctx = new BasicEvalContext(EvalType.Normal, depth, ClockManager.getTime());
		
		// Off limit should not be tracked and should not aggress
		TradeHistory.getInstance().onTrade(new Trade(TestUtils.PX_102, 1000, DayTiming.DAY_START_TIME));
		Map<IPrice, Long> goal = opt.optimize(ctx);
		assertTrue(goal.get(TestUtils.PX_101) == null);
		
		// Onside of limit. should be tracked and need to aggress
		TradeHistory.getInstance().onTrade(new Trade(TestUtils.PX_100, 1000, DayTiming.DAY_START_TIME));
		goal = opt.optimize(ctx);
		assertEquals(30L, (long)goal.get(TestUtils.PX_101));
	}
	
	@Test
	public void testPassivePosting() {
		ClientOrder order = new ClientOrder(true, new Instrument(), TestUtils.PX_101, 10000, TradingStrategy.POV);
		TargetRatioFn target = new TargetRatioFn(0, 0.05, 0);
		order.addTargetRatioFn(TestUtils.PX_101, target);
		
		BasicPovOptimizer opt = new BasicPovOptimizer(order);
		BasicEvalContext ctx = new BasicEvalContext(EvalType.Normal, depth, ClockManager.getTime());
		Map<IPrice, Long> goal = opt.optimize(ctx);
		assertEquals(50L, (long)goal.get(TestUtils.PX_100));
		assertEquals(50L, (long)goal.get(TestUtils.PX_99));
		assertEquals(goal.size(), 2);
	}
	
	@Test
	public void testSpeedupPosting() {
		ClientOrder order = new ClientOrder(true, new Instrument(), TestUtils.PX_101, 10000, TradingStrategy.POV);
		TargetRatioFn target = new TargetRatioFn(0, 0.05, 0);
		order.addTargetRatioFn(TestUtils.PX_101, target);
		TargetRatioFn speed = new TargetRatioFn(0, 0.1, 0);
		order.addTargetRatioFn(TestUtils.PX_99, speed);
		
		BasicPovOptimizer opt = new BasicPovOptimizer(order);
		BasicEvalContext ctx = new BasicEvalContext(EvalType.Normal, depth, ClockManager.getTime());
		Map<IPrice, Long> goal = opt.optimize(ctx);
		assertEquals(50L, (long)goal.get(TestUtils.PX_100));
		assertEquals(100L, (long)goal.get(TestUtils.PX_99));
		assertEquals(goal.size(), 2);
	}
}
