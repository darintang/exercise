package com.dt.optimizer;

import static org.junit.Assert.*;

import org.junit.Test;

import com.dt.core.Price;
import com.dt.core.orders.BasicPartition;
import com.dt.core.orders.PartitionType;
import com.dt.utils.TestUtils;

public class BookImbalanceCatchupOptimizerTest {

	@Test
	public void testCatchupDecisionBuy() {
		Price PX_100 = new Price(100);
		Price PX_101 = new Price(101);

		BookImbalanceCatchupOptimizer opt = new BookImbalanceCatchupOptimizer(true);
		BasicPartition part = new BasicPartition(true, PartitionType.AGGRESSIVE, 1000);
		
		opt.update(TestUtils.createDepth(PX_100, 1000, PX_101, 1000));
		assertFalse(opt.shouldCatchup());
		opt.doCatchUp(part, 100);
		assertEquals(part.getTotalQty(), 100);
		assertTrue(part.getGoal().get(PX_100) == 100L);

		opt.update(TestUtils.createDepth(PX_100, 2000, PX_101, 1000));
		assertTrue(opt.shouldCatchup());
		part = new BasicPartition(true, PartitionType.AGGRESSIVE, 1000);
		opt.doCatchUp(part, 100);
		assertEquals(part.getTotalQty(), 100);
		assertTrue(part.getGoal().get(PX_101) == 100L);

		opt.update(TestUtils.createDepth(PX_100, 1000, PX_101, 2000));
		assertFalse(opt.shouldCatchup());
		part = new BasicPartition(true, PartitionType.AGGRESSIVE, 1000);
		opt.doCatchUp(part, 100);
		assertEquals(part.getTotalQty(), 100);
		assertTrue(part.getGoal().get(PX_100) == 100L);
	}

	@Test
	public void testCatchupDecisionSell() {
		Price PX_100 = new Price(100);
		Price PX_101 = new Price(101);

		BookImbalanceCatchupOptimizer opt = new BookImbalanceCatchupOptimizer(false);
		BasicPartition part = new BasicPartition(false, PartitionType.AGGRESSIVE, 1000);
		
		opt.update(TestUtils.createDepth(PX_100, 1000, PX_101, 1000));
		assertFalse(opt.shouldCatchup());
		opt.doCatchUp(part, 100);
		assertEquals(part.getTotalQty(), 100);
		assertTrue(part.getGoal().get(PX_101) == 100L);

		opt.update(TestUtils.createDepth(PX_100, 2000, PX_101, 1000));
		assertFalse(opt.shouldCatchup());
		part = new BasicPartition(false, PartitionType.AGGRESSIVE, 1000);
		opt.doCatchUp(part, 100);
		assertEquals(part.getTotalQty(), 100);
		assertTrue(part.getGoal().get(PX_101) == 100L);

		opt.update(TestUtils.createDepth(PX_100, 1000, PX_101, 2000));
		assertTrue(opt.shouldCatchup());
		part = new BasicPartition(false, PartitionType.AGGRESSIVE, 1000);
		opt.doCatchUp(part, 100);
		assertEquals(part.getTotalQty(), 100);
		assertTrue(part.getGoal().get(PX_100) == 100L);
	}
}
