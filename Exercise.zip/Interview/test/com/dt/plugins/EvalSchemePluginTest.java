package com.dt.plugins;

import static org.junit.Assert.*;

import java.util.TreeMap;

import org.junit.Test;

import com.dt.CurrentDepth;
import com.dt.core.IPrice;
import com.dt.core.MarketDepth;
import com.dt.core.Price;
import com.dt.core.TradingMath;
import com.dt.optimizer.plugins.EvalSchemePlugin;
import com.dt.utils.TestUtils;

public class EvalSchemePluginTest {

	@Test
	public void testDepthEvalDecision() {
		CurrentDepth.updateSnapshot(TestUtils.createDepth(new Price(100), 1000, new Price(101), 1000));
		EvalSchemePlugin scheme = new EvalSchemePlugin();
		assertFalse(scheme.wantToOptimize(TestUtils.createDepth(new Price(100), 1000, new Price(101), 1000)));
		assertTrue(scheme.wantToOptimize(TestUtils.createDepth(new Price(100), 1000, new Price(102), 1000)));
		assertTrue(scheme.wantToOptimize(TestUtils.createDepth(new Price(100), 1000, null, 1000)));

		scheme.wantToOptimize(TestUtils.createDepth(new Price(100), 1000, new Price(101), 1000));
		assertTrue(scheme.wantToOptimize(TestUtils.createDepth(new Price(100), 1000, new Price(101), 2000)));
		assertFalse(scheme.wantToOptimize(TestUtils.createDepth(new Price(100), 1000, new Price(101), 2050)));
	}

	@Test
	public void testDepthEvalDecisionLowerDepthChange() {
		CurrentDepth.updateSnapshot(TestUtils.createDepth(new Price(100), 1000, new Price(101), 1000));
		EvalSchemePlugin scheme = new EvalSchemePlugin();

		TreeMap<IPrice, Long> bidMap = new TreeMap<IPrice, Long>(TradingMath.BUY_COMP);
		TreeMap<IPrice, Long> askMap = new TreeMap<IPrice, Long>(TradingMath.SELL_COMP);
		bidMap.put(new Price(100), 1000L);
		bidMap.put(new Price(99), 1000L);
		askMap.put(new Price(101), 1000L);
		askMap.put(new Price(102), 1000L);
		assertFalse(scheme.wantToOptimize(new MarketDepth(bidMap, askMap)));

	}

}
