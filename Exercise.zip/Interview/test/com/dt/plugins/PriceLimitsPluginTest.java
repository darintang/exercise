package com.dt.plugins;

import static org.junit.Assert.*;

import java.util.Map;
import java.util.TreeMap;

import org.junit.Test;

import com.dt.core.IPrice;
import com.dt.core.Instrument;
import com.dt.core.Price;
import com.dt.core.TradingMath;
import com.dt.core.TradingStrategy;
import com.dt.core.orders.ClientOrder;
import com.dt.optimizer.plugins.PriceLimitsPlugin;
import com.dt.utils.TestUtils;

public class PriceLimitsPluginTest {

	private static IPrice LIMIT = new Price(102);
	private static IPrice PX_103 = new Price(103);
	private static IPrice PX_101 = new Price(101);

	@Test
	public void testLmtRePricing() {
		Map<IPrice, Long> goal = new TreeMap<IPrice, Long>(TradingMath.BUY_COMP);
		Map<IPrice, Long> expected = new TreeMap<IPrice, Long>(TradingMath.BUY_COMP);
		ClientOrder order = new ClientOrder(true, new Instrument(), LIMIT, 10000, TradingStrategy.VWAP);
		PriceLimitsPlugin pxLimit = new PriceLimitsPlugin(order, new TradingMath(true, new Instrument()));

		goal.put(PX_103, 1000L);
		expected.put(LIMIT, 1000L);
		assertTrue(pxLimit.adjustPrice(goal));
		TestUtils.assertSameMap(goal, expected);

		goal.clear();
		expected.clear();
		goal.put(PX_103, 1000L);
		goal.put(LIMIT, 1000L);
		expected.put(LIMIT, 2000L);
		assertTrue(pxLimit.adjustPrice(goal));
		TestUtils.assertSameMap(goal, expected);

		goal.clear();
		expected.clear();
		goal.put(LIMIT, 1000L);
		expected.put(LIMIT, 1000L);
		assertFalse(pxLimit.adjustPrice(goal));
		TestUtils.assertSameMap(goal, expected);

		goal.clear();
		expected.clear();
		goal.put(PX_101, 1000L);
		expected.put(PX_101, 1000L);
		assertFalse(pxLimit.adjustPrice(goal));
		TestUtils.assertSameMap(goal, expected);
	}
	
	@Test
	public void testMktRePricing() {
		Map<IPrice, Long> goal = new TreeMap<IPrice, Long>(TradingMath.BUY_COMP);
		Map<IPrice, Long> expected = new TreeMap<IPrice, Long>(TradingMath.BUY_COMP);
		ClientOrder order = new ClientOrder(true, new Instrument(), Price.MARKET, 10000, TradingStrategy.VWAP);
		PriceLimitsPlugin pxLimit = new PriceLimitsPlugin(order, new TradingMath(true, new Instrument()));

		goal.put(PX_103, 1000L);
		expected.put(PX_103, 1000L);
		assertFalse(pxLimit.adjustPrice(goal));
		TestUtils.assertSameMap(goal, expected);

		goal.clear();
		expected.clear();
		goal.put(PX_103, 1000L);
		goal.put(LIMIT, 1000L);
		expected.put(PX_103, 1000L);
		expected.put(LIMIT, 1000L);
		assertFalse(pxLimit.adjustPrice(goal));
		TestUtils.assertSameMap(goal, expected);

		goal.clear();
		expected.clear();
		goal.put(LIMIT, 1000L);
		expected.put(LIMIT, 1000L);
		assertFalse(pxLimit.adjustPrice(goal));
		TestUtils.assertSameMap(goal, expected);

		goal.clear();
		expected.clear();
		goal.put(PX_101, 1000L);
		expected.put(PX_101, 1000L);
		assertFalse(pxLimit.adjustPrice(goal));
		TestUtils.assertSameMap(goal, expected);
	}
}